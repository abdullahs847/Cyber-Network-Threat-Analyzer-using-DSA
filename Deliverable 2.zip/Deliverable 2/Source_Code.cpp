#include <iostream>
#include <string>
#include <queue>
using namespace std;

// DEVICE STRUCTURE
struct Device {
    string name;
    bool quarantined = false;   // Mark device as quarantined if isolated
    Device* next;               // Pointer to next device 
};

//  CONNECTION STRUCTURE 
struct Connection {
    string from;
    string to;
    Connection* next;
    Connection* prev;
};

// DEVICE LIST CLASS 
class DeviceList {
private:
    Device* head;
public:
    DeviceList() : head(nullptr) {}

    void addDevice(string name) {
        Device* newDevice = new Device{name, false, nullptr};
        if (!head)
            head = newDevice;
        else {
            Device* temp = head;
            while (temp->next)
                temp = temp->next;
            temp->next = newDevice;
        }
        cout << "Device " << name << " added successfully!\n";
    }

    
    Device* findDevice(string name) {
        Device* temp = head;
        while (temp) {
            if (temp->name == name)
                return temp;
            temp = temp->next;
        }
        return nullptr;
    }

    void showDevices() {
        if (!head) {
            cout << "No devices in the network.\n";
            return;
        }
        cout << "\nDevices in Network: ";
        Device* temp = head;
        while (temp) {
            cout << temp->name;
            if (temp->quarantined)
                cout << " [Q]";
            if (temp->next)
                cout << " -> ";
            temp = temp->next;
        }
        cout << "\n";
    }

    Device* getHead() { return head; }
};

//  CONNECTION LIST CLASS 
class ConnectionList {
private:
    Connection* head;
    Connection* tail;
public:
    ConnectionList() : head(nullptr), tail(nullptr) {}

    void addConnection(string from, string to) {
        Connection* newCon = new Connection{from, to, nullptr, nullptr};
        if (!head) {
            head = tail = newCon;
        } else {
            tail->next = newCon;
            newCon->prev = tail;
            tail = newCon;
        }
        cout << "Connection added: " << from << " -> " << to << endl;
    }

    void removeConnectionsForDevice(string deviceName) {
        Connection* current = head;
        while (current) {
            if (current->from == deviceName || current->to == deviceName) {
                Connection* toDelete = current;

                // Update links for previous and next nodes
                if (current->prev)
                    current->prev->next = current->next;
                else
                    head = current->next;  // if first node is removed

                if (current->next)
                    current->next->prev = current->prev;
                else
                    tail = current->prev;  // if last node is removed

                current = current->next;
                delete toDelete;
            } else {
                current = current->next;
            }
        }
    }

    void showConnections() {
        if (!head) {
            cout << "No connections available.\n";
            return;
        }
        cout << "\nNetwork Connections:\n";
        Connection* temp = head;
        while (temp) {
            cout << temp->from << " -> " << temp->to << endl;
            temp = temp->next;
        }
    }

    Connection* getHead() { return head; }
};

//  SIMULATOR CLASS 
class Simulator {
public:
    // Simulate infection spread using Queue (FIFO)
    void simulateInfection(DeviceList& devices, ConnectionList& connections, string startDevice) {
        Device* start = devices.findDevice(startDevice);
        if (!start) {
            cout << "Device not found.\n";
            return;
        }
        if (start->quarantined) {
            cout << "Cannot start infection from a quarantined device!\n";
            return;
        }

        cout << "\n--- Infection Spread Simulation (Queue - FIFO) ---\n";
        queue<string> q;
        q.push(startDevice);

        while (!q.empty()) {
            string current = q.front();
            q.pop();
            cout << current << " ";

            Connection* temp = connections.getHead();
            while (temp) {
                if (temp->from == current) {
                    Device* nextDevice = devices.findDevice(temp->to);
                    if (nextDevice && !nextDevice->quarantined)
                        q.push(temp->to);
                }
                temp = temp->next;
            }
        }
        cout << endl;
    }
};

//  MAIN FUNCTION
int main() {
    DeviceList devices;
    ConnectionList connections;
    Simulator sim;

    int choice;
    string a, b;

    do {
        system("cls");
        cout << "\n---------- Cyber Network Threat Analyzer (Basic Version) ----------\n";
        cout << "1. Add Device\n";
        cout << "2. Show Devices\n";
        cout << "3. Add Connection\n";
        cout << "4. Show Connections\n";
        cout << "5. Simulate Infection Spread \n";
        cout << "6. Quarantine Device \n";
        cout << "7. Exit\n";
        cout << "Enter choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            cout << "Enter device name: ";
            cin >> a;
            devices.addDevice(a);
            break;

        case 2:
            devices.showDevices();
            break;

        case 3:
            cout << "Enter connection (From To): ";
            cin >> a >> b;
            connections.addConnection(a, b);
            break;

        case 4:
            connections.showConnections();
            break;

        case 5:
            cout << "Enter starting infected device: ";
            cin >> a;
            sim.simulateInfection(devices, connections, a);
            break;

        case 6:
            cout << "Enter device to quarantine: ";
            cin >> a;
            {
                Device* d = devices.findDevice(a);
                if (d) {
                    d->quarantined = true;
                    connections.removeConnectionsForDevice(a);
                    cout << "Device " << a << " quarantined and disconnected from network!\n";
                } else {
                    cout << "Device not found.\n";
                }
            }
            break;

        case 7:
            cout << "Exiting program...\n";
            break;

        default:
            cout << "Invalid choice.\n";
        }
        system("pause");
    } while (choice != 7);

    return 0;
}
